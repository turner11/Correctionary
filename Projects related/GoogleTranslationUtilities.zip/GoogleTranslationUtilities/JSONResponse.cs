﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoogleTranslationAPI
{
   [Serializable]
   public class JSONResponse
   {
      public string responseDetails = null;
      public string responseStatus = null;
   }

}
