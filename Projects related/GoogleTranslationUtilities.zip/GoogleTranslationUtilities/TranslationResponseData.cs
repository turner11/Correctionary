﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoogleTranslationAPI
{
   [Serializable]
   public class TranslationResponseData
   {
      public string translatedText;
      //public string detectedSourceLanguage;
   }
}
